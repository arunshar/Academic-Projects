
##  Data Intensive Computing

### Projects contains various computing task on large scale data and performing analysis such as Exploratory Analysis, Big Data Analytics and Data Visualization on various datasets.

### Platform :  Java, Python, R, Jupyter, Hadoop, Tableau, Spark
