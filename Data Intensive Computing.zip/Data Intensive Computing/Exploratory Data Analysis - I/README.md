
##  Exploratory Data Analysis - I

### Gives geolocation and trends through analysing tweets
