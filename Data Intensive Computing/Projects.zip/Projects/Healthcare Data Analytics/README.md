
## Healthcare Data Analytics

### Analyze large scale WHO data of country-wise population statistics of people having TB and HIV. The detailed analysis is shown in the following link : https://public.tableau.com/profile/publish/Term_Project/Story#!/publish-confirm


